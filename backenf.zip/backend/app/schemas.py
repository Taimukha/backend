from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional
from datetime import datetime

# Exercise schemas
class ExerciseBase(BaseModel):
    name: str
    sets: int
    reps: int
    weight: int
    rest: int

class ExerciseCreate(ExerciseBase):
    pass

class ExerciseResponse(ExerciseBase):
    id: int
    workout_id: int

    class Config:
        orm_mode = True

# Workout schemas
class WorkoutBase(BaseModel):
    name: str
    description: Optional[str] = None
    type: str
    duration: int
    difficulty: str

class WorkoutCreate(WorkoutBase):
    exercises: List[ExerciseBase]

class WorkoutUpdate(WorkoutBase):
    exercises: List[ExerciseBase]

class WorkoutResponse(WorkoutBase):
    id: int
    created_by: int
    created_at: datetime
    exercises: List[ExerciseResponse]
    is_favorite: bool = False

    class Config:
        from_attributes = True


# User schemas
class UserBase(BaseModel):
    name: str
    email: EmailStr

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    avatar: Optional[str] = None
    role: Optional[str] = None

class UserResponse(UserBase):
    id: int
    avatar: Optional[str] = None
    role: str

    class Config:
        orm_mode = True

# Password change schema
class PasswordChange(BaseModel):
    current_password: str
    new_password: str

# Email schema for password reset
class EmailSchema(BaseModel):
    email: EmailStr

# Token schema
class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

# Favorite update schema
class FavoriteUpdate(BaseModel):
    is_favorite: bool

# Notification schemas
class NotificationBase(BaseModel):
    title: str
    message: str

class NotificationCreate(NotificationBase):
    related_id: int


class NotificationResponse(NotificationBase):
    id: int
    read: bool
    timestamp: datetime
    user_id: int

    class Config:
        orm_mode = True
