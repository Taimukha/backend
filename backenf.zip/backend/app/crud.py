from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, delete, update
from typing import List, Optional
import datetime
from fastapi import HTTPException

from . import models, schemas
from .auth import get_password_hash


# User CRUD operations
async def get_user(db: AsyncSession, user_id: int):
    stmt = select(models.User).where(models.User.id == user_id)
    result = await db.execute(stmt)
    return result.scalars().first()


async def get_user_by_email(db: AsyncSession, email: str):
    stmt = select(models.User).where(models.User.email == email)
    result = await db.execute(stmt)
    return result.scalars().first()


async def get_users(db: AsyncSession, skip: int = 0, limit: int = 100):
    stmt = select(models.User).offset(skip).limit(limit)
    result = await db.execute(stmt)
    return result.scalars().all()


async def count_admins(db: AsyncSession):
    stmt = select(func.count()).select_from(models.User).where(models.User.role == "admin")
    result = await db.execute(stmt)
    return result.scalar()


async def create_user(db: AsyncSession, user: schemas.UserCreate):
    hashed_password = get_password_hash(user.password)
    db_user = models.User(
        name=user.name,
        email=user.email,
        hashed_password=hashed_password
    )
    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)
    return db_user


async def update_user(db: AsyncSession, user_id: int, user: schemas.UserUpdate):
    stmt = select(models.User).where(models.User.id == user_id)
    result = await db.execute(stmt)
    db_user = result.scalars().first()

    if user.name is not None:
        db_user.name = user.name
    if user.email is not None:
        db_user.email = user.email
    if user.avatar is not None:
        db_user.avatar = user.avatar
    if user.role is not None:
        db_user.role = user.role

    await db.commit()
    await db.refresh(db_user)
    return db_user


async def update_user_password(db: AsyncSession, user_id: int, new_password: str):
    stmt = select(models.User).where(models.User.id == user_id)
    result = await db.execute(stmt)
    db_user = result.scalars().first()
    db_user.hashed_password = get_password_hash(new_password)
    await db.commit()
    return db_user


async def delete_user(db: AsyncSession, user_id: int):
    stmt = select(models.User).where(models.User.id == user_id)
    result = await db.execute(stmt)
    db_user = result.scalars().first()
    await db.delete(db_user)
    await db.commit()
    return db_user


# Workout CRUD operations
async def get_workout(db: AsyncSession, workout_id: int):
    stmt = (
        select(models.Workout)
        .where(models.Workout.id == workout_id)
        .options(selectinload(models.Workout.exercises))
    )
    result = await db.execute(stmt)
    return result.scalars().first()


async def get_user_workouts(db: AsyncSession, user_id: int, skip: int = 0, limit: int = 100):
    stmt = (
        select(models.Workout)
        .where(models.Workout.created_by == user_id)
        .options(selectinload(models.Workout.exercises))
        .offset(skip)
        .limit(limit)
    )
    result = await db.execute(stmt)
    return result.scalars().all()


from sqlalchemy.future import select
from sqlalchemy.orm import selectinload


async def create_workout(db: AsyncSession, workout: schemas.WorkoutCreate, user_id: int):
    try:
        db_workout = models.Workout(
            name=workout.name,
            description=workout.description,
            type=workout.type,
            duration=workout.duration,
            difficulty=workout.difficulty,
            created_by=user_id
        )
        db.add(db_workout)
        await db.flush()

        for exercise in workout.exercises:
            db_exercise = models.Exercise(
                name=exercise.name,
                sets=exercise.sets,
                reps=exercise.reps,
                weight=exercise.weight,
                rest=exercise.rest,
                workout_id=db_workout.id
            )
            db.add(db_exercise)

        await db.commit()  # commit бірінші
        await db.refresh(db_workout)

        # Commit-тен кейін қосымша логика болса, try/except бөлек
        stmt = select(models.Workout).options(selectinload(models.Workout.exercises)).where(
            models.Workout.id == db_workout.id)
        result = await db.execute(stmt)
        full_workout = result.scalars().first()

        return full_workout
    except Exception as e:
        await db.rollback()
        print("Create workout error:", e)
        raise



async def update_workout(db: AsyncSession, workout_id: int, workout: schemas.WorkoutUpdate):
    stmt = select(models.Workout).where(models.Workout.id == workout_id)
    result = await db.execute(stmt)
    db_workout = result.scalars().first()

    db_workout.name = workout.name
    db_workout.description = workout.description
    db_workout.type = workout.type
    db_workout.duration = workout.duration
    db_workout.difficulty = workout.difficulty

    await db.execute(delete(models.Exercise).where(models.Exercise.workout_id == workout_id))

    for exercise in workout.exercises:
        db_exercise = models.Exercise(
            name=exercise.name,
            sets=exercise.sets,
            reps=exercise.reps,
            weight=exercise.weight,
            rest=exercise.rest,
            workout_id=workout_id
        )
        db.add(db_exercise)

    await db.commit()
    await db.refresh(db_workout)
    return db_workout


async def delete_workout(db: AsyncSession, workout_id: int):
    stmt = select(models.Workout).where(models.Workout.id == workout_id)
    result = await db.execute(stmt)
    db_workout = result.scalars().first()
    await db.delete(db_workout)
    await db.commit()
    return db_workout


async def toggle_favorite(db: AsyncSession, workout_id: int, user_id: int, is_favorite: bool):
    workout_stmt = select(models.Workout).where(models.Workout.id == workout_id)
    workout_result = await db.execute(workout_stmt)
    db_workout = workout_result.scalars().first()

    # Қатынаспен бірге пайдаланушыны жүктеу
    user_stmt = (
        select(models.User)
        .where(models.User.id == user_id)
        .options(selectinload(models.User.favorite_workouts))
    )
    user_result = await db.execute(user_stmt)
    db_user = user_result.scalars().first()

    if db_user is None or db_workout is None:
        raise HTTPException(status_code=404, detail="User or workout not found")

    if is_favorite:
        if db_workout not in db_user.favorite_workouts:
            db_user.favorite_workouts.append(db_workout)
    else:
        if db_workout in db_user.favorite_workouts:
            db_user.favorite_workouts.remove(db_workout)

    await db.commit()
    await db.refresh(db_workout)
    setattr(db_workout, 'is_favorite', is_favorite)

    return db_workout


# Notification CRUD operations
async def get_notification(db: AsyncSession, notification_id: int):
    stmt = select(models.Notification).where(models.Notification.id == notification_id)
    result = await db.execute(stmt)
    return result.scalars().first()


async def get_user_notifications(db: AsyncSession, user_id: int):
    stmt = select(models.Notification).where(models.Notification.user_id == user_id).order_by(
        models.Notification.timestamp.desc())
    result = await db.execute(stmt)
    return result.scalars().all()


async def create_notification(db: AsyncSession, notification: schemas.NotificationCreate):
    db_notification = models.Notification(
        title=notification.title,
        message=notification.message,
        user_id=notification.user_id
    )
    db.add(db_notification)
    await db.commit()
    await db.refresh(db_notification)
    return db_notification


async def mark_notification_as_read(db: AsyncSession, notification_id: int):
    stmt = select(models.Notification).where(models.Notification.id == notification_id)
    result = await db.execute(stmt)
    db_notification = result.scalars().first()
    db_notification.read = True
    await db.commit()
    await db.refresh(db_notification)
    return db_notification


async def mark_all_notifications_as_read(db: AsyncSession, user_id: int):
    await db.execute(update(models.Notification).where(
        models.Notification.user_id == user_id,
        models.Notification.read == False
    ).values(read=True))
    await db.commit()


async def delete_notification(db: AsyncSession, notification_id: int):
    stmt = select(models.Notification).where(models.Notification.id == notification_id)
    result = await db.execute(stmt)
    db_notification = result.scalars().first()
    await db.delete(db_notification)
    await db.commit()
    return db_notification
