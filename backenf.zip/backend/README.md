# Workout Scheduler Backend

This is the FastAPI backend for the Workout Scheduler application.

## Features

- User authentication with JWT
- User management (CRUD operations)
- Workout management (CRUD operations)
- Exercise tracking
- Notifications system
- Role-based access control (user, admin)
- PostgreSQL database integration

## Requirements

- Python 3.8+
- PostgreSQL
- Docker (optional)

## Installation

### Using Docker (recommended)

1. Clone the repository:
   \`\`\`
   git clone https://github.com/yourusername/workout-scheduler-backend.git
   cd workout-scheduler-backend
   \`\`\`

2. Start the application with Docker Compose:
   \`\`\`
   docker-compose up -d
   \`\`\`

3. The API will be available at http://localhost:8000

### Manual Setup

1. Clone the repository:
   \`\`\`
   git clone https://github.com/yourusername/workout-scheduler-backend.git
   cd workout-scheduler-backend
   \`\`\`

2. Create a virtual environment:
   \`\`\`
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   \`\`\`

3. Install dependencies:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

4. Create a PostgreSQL database:
   \`\`\`
   createdb workout_scheduler
   \`\`\`

5. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Update the database URL and other settings

6. Run the application:
   \`\`\`
   uvicorn main:app --reload
   \`\`\`

7. The API will be available at http://localhost:8000

## API Documentation

Once the application is running, you can access the API documentation at:

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Connecting to the Frontend

To connect this backend to the React frontend:

1. Update the API base URL in the frontend:

\`\`\`typescript
// src/lib/api.ts

const API_BASE_URL = 'http://localhost:8000/api';

export const api = {
  async get(url: string) {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}${url}`, {
      headers: {
        'Authorization': token ? `Bearer ${token}` : '',
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Something went wrong');
    }
    
    return response.json();
  },
  
  async post(url: string, data?: any) {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}${url}`, {
      method: 'POST',
      headers: {
        'Authorization': token ? `Bearer ${token}` : '',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Something went wrong');
    }
    
    return response.json();
  },
  
  async put(url: string, data?: any) {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}${url}`, {
      method: 'PUT',
      headers: {
        'Authorization': token ? `Bearer ${token}` : '',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Something went wrong');
    }
    
    return response.json();
  },
  
  async delete(url: string) {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}${url}`, {
      method: 'DELETE',
      headers: {
        'Authorization': token ? `Bearer ${token}` : '',
        'Content-Type': 'application/json',
      },
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Something went wrong');
    }
    
    return response.json();
  },
};
\`\`\`

2. Update the authentication context to use the real API:

\`\`\`typescript
// src/contexts/AuthContext.tsx

// ... existing imports

export const AuthProvider = ({ children }: AuthProviderProps) => {
  // ... existing state

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");

        if (token) {
          // Real API call to validate the token
          const userData = await api.get("/auth/me");
          setUser(userData);
        }
      } catch (err) {
        console.error("Authentication check failed:", err);
        localStorage.removeItem("token");
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);

      // Real API call
      const response = await api.post("/auth/login", { email, password });

      localStorage.setItem("token", response.access_token);
      setUser(response.user);

      // ... rest of the function
    } catch (err: any) {
      setError(err.message || "Login failed");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // ... update other methods similarly

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
\`\`\`

3. Update the Redux slices to use the real API endpoints.

## License

MIT
