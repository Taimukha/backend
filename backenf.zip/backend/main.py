from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession

from typing import List, Optional
import uvicorn
from app.database import get_db

from app.database import engine
from app import models, schemas, crud, auth
from app.auth import get_current_user, get_current_active_user, get_current_admin_user

app = FastAPI(
    title="Workout Scheduler API",
    description="Backend API for the Workout Scheduler application",
    version="1.0.0"
)


@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(models.Base.metadata.create_all)


# Configure CORS
origins = [
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Auth endpoints
@app.post("/api/auth/register", response_model=schemas.UserResponse)
async def register_user(user: schemas.UserCreate, db: AsyncSession = Depends(get_db)):
    db_user = await crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    return await crud.create_user(db=db, user=user)


@app.post("/api/auth/login", response_model=schemas.Token)
async def login_for_access_token(form_data: schemas.UserLogin, db: AsyncSession = Depends(get_db)):
    user = await auth.authenticate_user(db, form_data.email, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = auth.create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer", "user": user}


@app.post("/api/auth/reset-password")
async def reset_password(email_data: schemas.EmailSchema, db: AsyncSession = Depends(get_db)):
    user = await crud.get_user_by_email(db, email=email_data.email)
    if not user:
        # Don't reveal that the user doesn't exist
        return {"message": "If the email exists, a password reset link has been sent"}

    # In a real app, you would send an email with a reset link
    # For this example, we'll just return a success message
    return {"message": "If the email exists, a password reset link has been sent"}


@app.get("/api/auth/me", response_model=schemas.UserResponse)
async def read_users_me(current_user: schemas.UserResponse = Depends(get_current_active_user)):
    return current_user


# User endpoints
@app.get("/api/users", response_model=List[schemas.UserResponse])
async def read_users(
        skip: int = 0,
        limit: int = 100,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_admin_user)
):
    users = await crud.get_users(db, skip=skip, limit=limit)
    return users


@app.get("/api/users/{user_id}", response_model=schemas.UserResponse)
async def read_user(
        user_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    if current_user.role != "admin" and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    db_user = await crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user


@app.put("/api/users/profile", response_model=schemas.UserResponse)
async def update_user_profile(
        user_update: schemas.UserUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    updated_user = await crud.update_user(db, user_id=current_user.id, user=user_update)
    return updated_user


@app.put("/api/users/change-password")
async def change_password(
        password_change: schemas.PasswordChange,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    # Verify current password
    user = await auth.authenticate_user(db, current_user.email, password_change.current_password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect"
        )

    # Update password
    await crud.update_user_password(db, user_id=current_user.id, new_password=password_change.new_password)
    return {"message": "Password updated successfully"}


@app.put("/api/users/{user_id}", response_model=schemas.UserResponse)
async def update_user(
        user_id: int,
        user_update: schemas.UserUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_admin_user)
):
    db_user = await crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    updated_user = await crud.update_user(db, user_id=user_id, user=user_update)
    return updated_user


@app.delete("/api/users/{user_id}")
async def delete_user(
        user_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_admin_user)
):
    db_user = await crud.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Prevent deleting the last admin
    if db_user.role == "admin":
        admin_count = await crud.count_admins(db)
        if admin_count <= 1:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete the last admin user"
            )

    await crud.delete_user(db, user_id=user_id)
    return {"message": "User deleted successfully"}


# Workout endpoints
from fastapi import HTTPException


@app.post("/api/workouts", response_model=schemas.WorkoutResponse)
async def create_workout(
        workout: schemas.WorkoutCreate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    try:
        created_workout = await crud.create_workout(db=db, workout=workout, user_id=current_user.id)
        return created_workout
    except Exception as e:
        # Қате туралы толық хабарды шығару (өзіңе керек болса)
        raise HTTPException(status_code=400, detail=f"Error creating workout: {str(e)}")


@app.get("/api/workouts", response_model=List[schemas.WorkoutResponse])
async def read_workouts(
        skip: int = 0,
        limit: int = 100,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    workouts = await crud.get_user_workouts(db, user_id=current_user.id, skip=skip, limit=limit)
    return workouts


@app.get("/api/workouts/{workout_id}", response_model=schemas.WorkoutResponse)
async def read_workout(
        workout_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_workout = await crud.get_workout(db, workout_id=workout_id)
    if db_workout is None:
        raise HTTPException(status_code=404, detail="Workout not found")
    return db_workout


@app.put("/api/workouts/{workout_id}", response_model=schemas.WorkoutResponse)
async def update_workout(
        workout_id: int,
        workout: schemas.WorkoutUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_workout = await crud.get_workout(db, workout_id=workout_id)
    if db_workout is None:
        raise HTTPException(status_code=404, detail="Workout not found")

    return await crud.update_workout(db=db, workout_id=workout_id, workout=workout)


@app.delete("/api/workouts/{workout_id}")
async def delete_workout(
        workout_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_workout = await crud.get_workout(db, workout_id=workout_id)
    if db_workout is None:
        raise HTTPException(status_code=404, detail="Workout not found")

    # Check if user has permission to delete this workout
    if db_workout.created_by != current_user.id and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to delete this workout"
        )

    await crud.delete_workout(db, workout_id=workout_id)
    return {"message": "Workout deleted successfully"}


@app.put("/api/workouts/{workout_id}/favorite", response_model=schemas.WorkoutResponse)
async def toggle_favorite(
        workout_id: int,
        favorite_data: schemas.FavoriteUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_workout = await crud.get_workout(db, workout_id=workout_id)
    if db_workout is None:
        raise HTTPException(status_code=404, detail="Workout not found")

    return await crud.toggle_favorite(
        db=db,
        workout_id=workout_id,
        user_id=current_user.id,
        is_favorite=favorite_data.is_favorite
    )


async def create_notification(db: AsyncSession, notification: schemas.NotificationCreate, id: int):
    db_notification = models.Notification(
        title=notification.title,
        message=notification.message,
        user_id=id,
    )
    db.add(db_notification)
    await db.commit()
    await db.refresh(db_notification)
    return db_notification


@app.post("/api/notifications", response_model=schemas.NotificationResponse, status_code=201)
async def create_notification_endpoint(
        notification: schemas.NotificationCreate,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    try:
        new_notification = await create_notification(db, notification, current_user.id)
        return new_notification
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error creating notification: {str(e)}")


# Notification endpoints
@app.get("/api/notifications", response_model=List[schemas.NotificationResponse])
async def read_notifications(
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    notifications = await crud.get_user_notifications(db, user_id=current_user.id)
    return notifications


@app.put("/api/notifications/{notification_id}/read")
async def mark_notification_as_read(
        notification_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_notification = await crud.get_notification(db, notification_id=notification_id)
    if db_notification is None:
        raise HTTPException(status_code=404, detail="Notification not found")

    # Check if notification belongs to the current user
    if db_notification.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    await crud.mark_notification_as_read(db, notification_id=notification_id)
    return {"message": "Notification marked as read"}


@app.put("/api/notifications/read-all")
async def mark_all_notifications_as_read(
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    await crud.mark_all_notifications_as_read(db, user_id=current_user.id)
    return {"message": "All notifications marked as read"}


@app.delete("/api/notifications/{notification_id}")
async def delete_notification(
        notification_id: int,
        db: AsyncSession = Depends(get_db),
        current_user: schemas.UserResponse = Depends(get_current_active_user)
):
    db_notification = await crud.get_notification(db, notification_id=notification_id)
    if db_notification is None:
        raise HTTPException(status_code=404, detail="Notification not found")

    # Check if notification belongs to the current user
    if db_notification.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )

    await crud.delete_notification(db, notification_id=notification_id)
    return {"message": "Notification deleted successfully"}


# Health check endpoint
@app.get("/api/health")
def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
