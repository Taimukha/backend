"""initial migration

Revision ID: f18626aa42f8
Revises: 9d4c33095e86
Create Date: 2025-05-19 00:05:40.767814

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f18626aa42f8'
down_revision = '9d4c33095e86'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
