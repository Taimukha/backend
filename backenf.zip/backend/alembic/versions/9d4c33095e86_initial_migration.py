"""initial migration

Revision ID: 9d4c33095e86
Revises: 3740d4b9aa09
Create Date: 2025-05-19 00:04:31.251408

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9d4c33095e86'
down_revision = '3740d4b9aa09'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
